/*
 * To change this license header, choose License Headers in Project Properties.
 * To change this template file, choose Tools | Templates
 * and open the template in the editor.
 */
package assessment4;



/**
 *
 * @author Krisnicole
 */
public class Assessment4 {

    /**
     * @param args the command line arguments
     */
    public static void main(String[] args) {
        // TODO code application logic here
      Main m= new Main();
      String str1 =  "string";
      System.out.println("The given strings is: "+str1);
      System.out.println("The string containing ng at last: "+m.endsNg(str1));
    }
    
}
